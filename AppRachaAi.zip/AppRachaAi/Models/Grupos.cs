namespace AppRachaAi.Models
{
    public class Grupo
    {
        public int Id { get; set; }
        public string Nome { get; set; } = string.Empty;
        public string Categoria { get; set; } = string.Empty; // Ex: "moradia", "lazer", "alimentacao"
        public decimal Valor { get; set; }       // Positivo = a receber, Negativo = a pagar
        public int TotalMembros { get; set; }
        public DateTime DataUltimaAtividade { get; set; }

        // Propriedades calculadas
        public bool EstaNoDivida => Valor < 0;
        public string IconeCategoria => Categoria.ToLower() switch
        {
            "moradia"     => "🏠",
            "lazer"       => "🎉",
            "alimentacao" => "🍔",
            "viagem"      => "✈️",
            "academia"    => "💪",
            "streaming"   => "📺",
            _             => "💰"
        };
    }
}